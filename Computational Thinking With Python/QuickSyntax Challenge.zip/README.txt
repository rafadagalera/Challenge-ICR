Sprint 3 Challenge ICR

Grupo QuickSyntax

Rafael Nascimento
Luis Alberto
Vinicius Taiki
Enzzo Monteiro

Descrição da aplicação:
A aplicação contida nessa pasta é uma simples simulação feita em python da experiência dos usuários do nosso projeto para a Challenge, que por sua vez consiste de um website.
Essa aplicação conta com diversas funções inseridas em um menu principal, como uma função de criação de conta, login, informações sobre as personagens fictícias que fazem parte da nossa solução, os "Amigos da Saúde", ajuda e sair
Além disso, após efetuado o login no sistema, os usuários são inseridos em um novo menu apenas para pacientes logados, que consiste em novas funções como a criação de avatar, vizualização de avatares, alteração de avatares, ajuda(opção diferente do menu principal) e voltar para o menu principal(efetuar logout)

Instruções de uso:
Para utilizar essa aplicação é necessário baixar os arquivos funcoes.py e main.py
O usuário deve executar a função menu() no arquivo main.py e seguir as instruções imprimidas no terminal. O programa roda continuamente até a opção 0 - "Sair" ser escolhida.
É importante notar que a aplicação está programada para apagar todos os dados cadastrados anteriormente no começo de uma nova execução.
Incentivamos à quaisquer testadores de nossa aplicação a digitar "4" no terminal enquanto a aplicação estiver funcionando no caso de dúvidas.