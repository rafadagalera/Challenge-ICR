from funcoes import menu

menu()